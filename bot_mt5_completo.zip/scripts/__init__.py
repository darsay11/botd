"""
Paquete scripts - Scripts de utilidad.
"""

# Este archivo puede estar vacío