"""
Paquete ui.components - Componentes de la interfaz.
"""

# Este archivo puede estar vacío