"""
Paquete ui - Interfaz gráfica.
"""

from .main_window import MainWindow

__all__ = [
    'MainWindow'
]