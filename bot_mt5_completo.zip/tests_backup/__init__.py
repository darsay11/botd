"""
Paquete tests - Pruebas unitarias.
"""

# Este archivo puede estar vacío